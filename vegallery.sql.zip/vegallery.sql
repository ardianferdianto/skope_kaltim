-- phpMyAdmin SQL Dump
-- version 3.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 03, 2014 at 08:57 AM
-- Server version: 5.0.70
-- PHP Version: 5.2.10-pl0-gentoo

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vegallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `parentId` int(11) default NULL,
  `details` text,
  `cover` varchar(300) default NULL,
  `type` smallint(1) default NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `parentId`, `details`, `cover`, `type`, `created`, `modified`) VALUES
(1, 'BSE(Buku Sekolah Elektronik)', NULL, NULL, NULL, 1, '2014-04-03', '2014-04-03'),
(2, 'BSE Non Kemendiknas', NULL, NULL, NULL, 1, '0000-00-00', '0000-00-00'),
(3, 'Character Building', NULL, NULL, NULL, 1, '0000-00-00', '0000-00-00'),
(4, 'Life Skill', NULL, NULL, NULL, 1, '0000-00-00', '0000-00-00'),
(5, 'Komputer', NULL, NULL, NULL, 1, '0000-00-00', '0000-00-00'),
(6, 'Fiksi', NULL, NULL, NULL, 1, '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `ebooks`
--

CREATE TABLE IF NOT EXISTS `ebooks` (
  `id` int(11) NOT NULL auto_increment,
  `kelas` int(11) default NULL,
  `matapelajaran` int(11) default NULL,
  `author` int(11) NOT NULL,
  `category_id` int(11) default NULL,
  `title` varchar(100) NOT NULL,
  `penerbit` varchar(200) default NULL,
  `pengarang` varchar(200) default NULL,
  `produksi` varchar(200) default NULL,
  `sutradara` varchar(200) default NULL,
  `jumlahhalaman` int(10) default NULL,
  `tahun` year(4) default NULL,
  `details` text,
  `cover` varchar(300) default NULL,
  `type` smallint(1) default NULL,
  `file` varchar(100) NOT NULL,
  `dir` varchar(255) default NULL,
  `mimetype` varchar(255) default NULL,
  `filesize` int(11) default NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `ebooks`
--

INSERT INTO `ebooks` (`id`, `kelas`, `matapelajaran`, `author`, `category_id`, `title`, `penerbit`, `pengarang`, `produksi`, `sutradara`, `jumlahhalaman`, `tahun`, `details`, `cover`, `type`, `file`, `dir`, `mimetype`, `filesize`, `created`, `modified`) VALUES
(48, NULL, NULL, 1, 3, 'Character Buildings', 'Pemerintah', 'Pemerintah', NULL, NULL, 100, 0000, 'Ini resensi', 'img/2014-04-03-003704Screen_Shot_2014-04-01_at_3.54.10_PM.png', 1, 'soal_pkn_Pilihan_Ganda_Mudah.pdf', 'files/ebooks', 'application/pdf', 118938, '2014-04-03 04:09:49', '2014-04-03 08:15:18'),
(37, NULL, NULL, 1, 1, 'Bahasa dan Sastra Indonesia', 'Pusat Perbukuan Depdiknas', 'Sawali dan Ch. Susanto', NULL, NULL, 100, 2011, 'Bahasa dan Sastra Indonesia', 'img/bindo.png', 1, 'Bahasa-dan-Sastra-Indonesia.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(38, NULL, NULL, 1, 1, 'Bahasa Inggris', 'Pusat Perbukuan Depdiknas', 'Tn. Kumalarini dan Tim', NULL, NULL, 100, 2011, 'Bahasa Inggris', 'img/inggris.png', 1, 'Bahasa-Inggris.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(39, NULL, NULL, 1, 1, 'Generasi Cyber TIK', 'Pusat Perbukuan Depdiknas', 'Dede Imat Mutakin dan Tim', NULL, NULL, 100, 2011, 'Generasi Cyber TIK', 'img/cyber.png', 1, 'Generasi-Cyber-Teknologi-Informasi-dan-Komunikasi.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(40, NULL, NULL, 1, 1, 'Ilmu Pengetahuan Alam Terpadu', 'Pusat Perbukuan Depdiknas', 'Setya Nurachmandani dan Tim', NULL, NULL, 100, 2011, 'Ilmu Pengetahuan Alam', 'img/ipa.png', 1, 'Ilmu-Pengetahuan-Alam-(Terpadu).pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(41, NULL, NULL, 1, 1, 'Ilmu Pengetahuan Sosial', 'Pusat Perbukuan Depdiknas', 'Herlan Firmansyah', NULL, NULL, 100, 2011, 'Ilmu Pengetahuan Sosial', 'img/ips.png', 1, 'Ilmu-Pengetahuan-Sosial-2.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(42, NULL, NULL, 1, 1, 'Jelajah Cakrawala Sosial', 'Pusat Perbukuan Depdiknas', 'Nurhad dan Tim', NULL, NULL, 100, 2011, 'Jelajah Cakrawala Sosial', 'img/jelajah.png', 1, 'Jelajah-Cakrawala-Sosial.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(43, NULL, NULL, 1, 1, 'Pendidikan Jasmani Olahraga dan Kesehatan', 'Pusat Perbukuan Depdiknas', 'Aan Sunjata Wisahati dan Tim', NULL, NULL, 100, 2011, 'Pendidikan Jasmani Olahraga dan Kesehatan', 'img/penjas.png', 1, 'Pendidikan-Jasmani-Olahraga-dan-Kesehatan-3.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(44, NULL, NULL, 1, 1, 'Pendidikan Kewarganegaraan', 'Pusat Perbukuan Depdiknas', 'Sugiyono dan Tim', NULL, NULL, 100, 2011, 'Pendidikan Kewarganegaraan', 'img/pkn.png', 1, 'Pendidikan-Kewarganegaraan.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(45, NULL, NULL, 1, 1, 'Penunjang Belajar Matematika', 'Pusat Perbukuan Depdiknas', 'Dame Rosida Manik', NULL, NULL, 100, 2011, 'Penunjang Belajar Matematika', 'img/mtk.png', 1, 'Penunjang-Belajar-Matematika.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54'),
(46, NULL, NULL, 1, 1, 'Teknologi Informasi dan Komunikasi', 'Pusat Perbukuan Depdiknas', 'Dhanang Sukmana Adi dan Tim', NULL, NULL, 100, 2011, 'Teknologi Informasi dan Komunikasi', 'img/tik.png', 1, 'Teknologi-Informasi-Dan-Komunikasi.pdf', 'files/ebooks', 'application/pdf', 1209236, '2014-04-02 21:04:54', '2014-04-02 21:04:54');

-- --------------------------------------------------------

--
-- Table structure for table `pelajarans`
--

CREATE TABLE IF NOT EXISTS `pelajarans` (
  `id` int(11) NOT NULL auto_increment,
  `nama` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `pelajarans`
--

INSERT INTO `pelajarans` (`id`, `nama`, `created`, `modified`) VALUES
(1, 'Matematika', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(2, 'Fisika', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(3, 'Biologi', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(4, 'Bahasa Indonesia', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(5, 'Bahasa Inggris', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(6, 'PPKN', '2011-11-26 02:10:08', '2011-11-26 02:10:08'),
(8, 'Kimia', '2012-06-11 04:57:13', '2012-06-11 04:57:13'),
(9, 'TIK', '2012-06-11 04:57:27', '2012-06-11 04:57:27'),
(10, 'Sosiologi', '2012-06-11 04:57:38', '2012-06-11 04:57:38'),
(11, 'Sejarah', '2012-06-11 04:58:09', '2012-06-11 04:58:09'),
(12, 'Geografi', '2012-06-11 04:58:20', '2012-06-11 04:58:20'),
(13, 'Ekonomi', '2012-06-11 04:58:27', '2012-06-11 04:58:27'),
(14, 'Peta Indonesia Interaktif', '2012-06-11 04:58:44', '2012-06-11 04:58:44'),
(15, 'BSE(Buku Sekolah Elektronik)', '2014-04-03 02:36:45', '2014-04-03 02:36:45');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL auto_increment,
  `kelas` int(11) default NULL,
  `matapelajaran` int(11) default NULL,
  `author` int(11) NOT NULL,
  `category_id` int(11) default NULL,
  `title` varchar(100) NOT NULL,
  `penerbit` varchar(200) default NULL,
  `pengarang` varchar(200) default NULL,
  `produksi` varchar(200) default NULL,
  `sutradara` varchar(200) default NULL,
  `jumlahhalaman` int(10) default NULL,
  `tahun` year(4) default NULL,
  `details` text,
  `cover` varchar(300) default NULL,
  `type` smallint(1) NOT NULL,
  `file` varchar(100) NOT NULL,
  `dir` varchar(255) default NULL,
  `mimetype` varchar(255) default NULL,
  `filesize` int(11) default NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `videos`
--

